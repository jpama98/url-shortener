from fastapi import FastAPI, Request
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address

from app.api.shorten import router as shorten_router
from app.api.redirect import router as redirect_router
from app.api.analytics import router as analytics_router

limiter = Limiter(key_func=get_remote_address)

app = FastAPI(title="URL Shortener", version="1.0.0")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)

app.include_router(shorten_router, prefix="/api/v1", tags=["shorten"])
app.include_router(redirect_router, tags=["redirect"])
app.include_router(analytics_router, prefix="/api/v1", tags=["analytics"])
