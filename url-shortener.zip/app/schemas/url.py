from pydantic import BaseModel, HttpUrl
from datetime import datetime
from typing import Optional

class ShortenRequest(BaseModel):
    original_url: HttpUrl

class ShortenResponse(BaseModel):
    short_code: str
    short_url: str
    created_at: datetime

class AnalyticsResponse(BaseModel):
    short_code: str
    original_url: str
    total_clicks: int
    created_at: datetime
    last_clicked_at: Optional[datetime]
