import uuid
from sqlalchemy import String, DateTime, func, Integer
from sqlalchemy.orm import declarative_base, Mapped, mapped_column

Base = declarative_base()

class ShortURL(Base):
    __tablename__ = "short_urls"

    id: Mapped[uuid.UUID] = mapped_column(primary_key=True, default=uuid.uuid4)
    original_url: Mapped[str] = mapped_column(String(2048), nullable=False)
    short_code: Mapped[str] = mapped_column(String(16), unique=True, index=True, nullable=False)
    created_at: Mapped[str] = mapped_column(DateTime(timezone=True), server_default=func.now())
    click_count: Mapped[int] = mapped_column(Integer, default=0)
    last_clicked_at: Mapped[str] = mapped_column(DateTime(timezone=True), nullable=True)
